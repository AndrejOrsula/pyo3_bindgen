use pyo3::{prelude::*, types::PyModule};
use std::ffi::CString;

include!("bindings.rs");

fn main() -> PyResult<()> {
    Python::attach(|py| {
        let source = CString::new(include_str!("../greeting.py"))
            .expect("fixture source contains no NUL byte");
        let filename = CString::new("greeting.py").expect("static filename contains no NUL byte");
        let module_name = CString::new("greeting").expect("static module name contains no NUL byte");
        let module = PyModule::from_code(
            py,
            source.as_c_str(),
            filename.as_c_str(),
            module_name.as_c_str(),
        )?;
        py.import("sys")?.getattr("modules")?.set_item("greeting", module)?;
        let greeting = greeting::greet_builder(py, "Ada")?.call()?;
        assert_eq!(greeting, "Hello, Ada!");
        println!("greeting: {greeting}");
        Ok(())
    })
}
