#[allow(
    clippy::all,
    clippy::nursery,
    clippy::pedantic,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused
)]
/// Optional arguments, which call builders let Rust leave out.
pub mod greeting {
    #[doc(hidden)]
    pub const PYO3_BINDGEN_GENERATOR_VERSION: &str = "0.6.0";
    #[doc(hidden)]
    pub const PYO3_BINDGEN_MODULE_NAME: &str = "greeting";
    #[doc(hidden)]
    pub const PYO3_BINDGEN_INPUT_HASH: &str = "fnv1a64:38a805415f3a84a7";
    /// Greets someone, by default politely.
    pub fn greet<'py>(
        py: ::pyo3::marker::Python<'py>,
        p_name: &str,
        p_greeting: &str,
        p_punctuation: &str,
        p_shout: bool,
    ) -> ::pyo3::PyResult<::std::string::String> {
        ::std::result::Result::Ok(
            ::pyo3::types::PyAnyMethods::extract(
                &::pyo3::types::PyAnyMethods::call_method1(
                    py.import(::pyo3::intern!(py, "greeting"))?.as_any(),
                    ::pyo3::intern!(py, "greet"),
                    ::pyo3::types::PyTuple::new(
                        py,
                        [
                            ::pyo3::IntoPyObjectExt::into_bound_py_any(p_name, py)?,
                            ::pyo3::IntoPyObjectExt::into_bound_py_any(p_greeting, py)?,
                            ::pyo3::IntoPyObjectExt::into_bound_py_any(
                                p_punctuation,
                                py,
                            )?,
                            ::pyo3::IntoPyObjectExt::into_bound_py_any(p_shout, py)?,
                        ],
                    )?,
                )?,
            )?,
        )
    }
    /// Sums any number of scores, plus a bonus.
    pub fn tally<'py>(
        py: ::pyo3::marker::Python<'py>,
        p_scores: &::pyo3::Bound<'py, ::pyo3::types::PyTuple>,
        p_bonus: i64,
    ) -> ::pyo3::PyResult<i64> {
        ::std::result::Result::Ok(
            ::pyo3::types::PyAnyMethods::extract(
                &::pyo3::types::PyAnyMethods::call_method(
                    py.import(::pyo3::intern!(py, "greeting"))?.as_any(),
                    ::pyo3::intern!(py, "tally"),
                    p_scores,
                    Some(
                        &{
                            let __internal__kwargs = ::pyo3::types::PyDict::new(py);
                            ::pyo3::types::PyDictMethods::set_item(
                                &__internal__kwargs,
                                ::pyo3::intern!(py, "bonus"),
                                p_bonus,
                            )?;
                            __internal__kwargs
                        },
                    ),
                )?,
            )?,
        )
    }
    ///Attachment-bound arguments for greeting.greet. Unused setters omit arguments; supplied None for a named Optional stays Python None. Defaults and the callable are resolved by call. Conversions may execute Python in the entry point or setters.
    pub struct greetCall<'py> {
        __pyo3_py: ::pyo3::Python<'py>,
        p_name: ::std::option::Option<::pyo3::Bound<'py, ::pyo3::types::PyAny>>,
        p_greeting: ::std::option::Option<::pyo3::Bound<'py, ::pyo3::types::PyAny>>,
        p_punctuation: ::std::option::Option<::pyo3::Bound<'py, ::pyo3::types::PyAny>>,
        p_shout: ::std::option::Option<::pyo3::Bound<'py, ::pyo3::types::PyAny>>,
    }
    impl<'py> greetCall<'py> {
        ///Supply Python argument "greeting". Replaces a previous supplied value. Conversion can execute Python now; leaving this setter unused omits the argument.
        pub fn with_greeting(mut self, p_greeting: &str) -> ::pyo3::PyResult<Self> {
            let py = self.__pyo3_py;
            self.p_greeting = ::std::option::Option::Some(
                ::pyo3::IntoPyObjectExt::into_bound_py_any(p_greeting, py)?,
            );
            ::std::result::Result::Ok(self)
        }
        ///Supply Python argument "punctuation". Replaces a previous supplied value. Conversion can execute Python now; leaving this setter unused omits the argument.
        pub fn with_punctuation(
            mut self,
            p_punctuation: &str,
        ) -> ::pyo3::PyResult<Self> {
            let py = self.__pyo3_py;
            self.p_punctuation = ::std::option::Option::Some(
                ::pyo3::IntoPyObjectExt::into_bound_py_any(p_punctuation, py)?,
            );
            ::std::result::Result::Ok(self)
        }
        ///Supply Python argument "shout". Replaces a previous supplied value. Conversion can execute Python now; leaving this setter unused omits the argument.
        pub fn with_shout(mut self, p_shout: bool) -> ::pyo3::PyResult<Self> {
            let py = self.__pyo3_py;
            self.p_shout = ::std::option::Option::Some(
                ::pyo3::IntoPyObjectExt::into_bound_py_any(p_shout, py)?,
            );
            ::std::result::Result::Ok(self)
        }
        /// Invoke the current Python callable, using Python's current defaults.
        /// Nonempty variadic positional arguments require every preceding positional slot.
        pub fn call(self) -> ::pyo3::PyResult<::std::string::String> {
            let py = self.__pyo3_py;
            let __pyo3_kwargs = ::pyo3::types::PyDict::new(py);
            let __pyo3_has_variadic = false;
            let mut __pyo3_args = ::std::vec::Vec::<
                ::pyo3::Bound<'py, ::pyo3::types::PyAny>,
            >::new();
            let mut __pyo3_positional_gap = false;
            if let ::std::option::Option::Some(value) = self.p_name {
                if __pyo3_has_variadic {
                    __pyo3_args.push(value);
                } else {
                    ::pyo3::types::PyDictMethods::set_item(
                        &__pyo3_kwargs,
                        "name",
                        value,
                    )?;
                }
            } else if __pyo3_has_variadic {
                return ::std::result::Result::Err(
                    ::pyo3::exceptions::PyTypeError::new_err(
                        "argument \"name\" must be supplied before nonempty variadic positional arguments",
                    ),
                );
            }
            if let ::std::option::Option::Some(value) = self.p_greeting {
                if __pyo3_has_variadic {
                    __pyo3_args.push(value);
                } else {
                    ::pyo3::types::PyDictMethods::set_item(
                        &__pyo3_kwargs,
                        "greeting",
                        value,
                    )?;
                }
            } else if __pyo3_has_variadic {
                return ::std::result::Result::Err(
                    ::pyo3::exceptions::PyTypeError::new_err(
                        "argument \"greeting\" must be supplied before nonempty variadic positional arguments",
                    ),
                );
            }
            if let ::std::option::Option::Some(value) = self.p_punctuation {
                if __pyo3_has_variadic {
                    __pyo3_args.push(value);
                } else {
                    ::pyo3::types::PyDictMethods::set_item(
                        &__pyo3_kwargs,
                        "punctuation",
                        value,
                    )?;
                }
            } else if __pyo3_has_variadic {
                return ::std::result::Result::Err(
                    ::pyo3::exceptions::PyTypeError::new_err(
                        "argument \"punctuation\" must be supplied before nonempty variadic positional arguments",
                    ),
                );
            }
            if let ::std::option::Option::Some(value) = self.p_shout {
                if __pyo3_has_variadic {
                    __pyo3_args.push(value);
                } else {
                    ::pyo3::types::PyDictMethods::set_item(
                        &__pyo3_kwargs,
                        "shout",
                        value,
                    )?;
                }
            } else if __pyo3_has_variadic {
                return ::std::result::Result::Err(
                    ::pyo3::exceptions::PyTypeError::new_err(
                        "argument \"shout\" must be supplied before nonempty variadic positional arguments",
                    ),
                );
            }
            let __pyo3_args = ::pyo3::types::PyTuple::new(py, __pyo3_args)?;
            ::std::result::Result::Ok(
                ::pyo3::types::PyAnyMethods::extract(
                    &::pyo3::types::PyAnyMethods::call_method(
                        py.import(::pyo3::intern!(py, "greeting"))?.as_any(),
                        ::pyo3::intern!(py, "greet"),
                        __pyo3_args,
                        ::std::option::Option::Some(&__pyo3_kwargs),
                    )?,
                )?,
            )
        }
    }
    pub fn greet_builder<'py>(
        py: ::pyo3::Python<'py>,
        p_name: &str,
    ) -> ::pyo3::PyResult<greetCall<'py>> {
        ::std::result::Result::Ok(greetCall {
            __pyo3_py: py,
            p_name: ::std::option::Option::Some(
                ::pyo3::IntoPyObjectExt::into_bound_py_any(p_name, py)?,
            ),
            p_greeting: ::std::option::Option::None,
            p_punctuation: ::std::option::Option::None,
            p_shout: ::std::option::Option::None,
        })
    }
    ///Attachment-bound arguments for greeting.tally. Unused setters omit arguments; supplied None for a named Optional stays Python None. Defaults and the callable are resolved by call. Conversions may execute Python in the entry point or setters.
    pub struct tallyCall<'py> {
        __pyo3_py: ::pyo3::Python<'py>,
        p_scores: ::std::option::Option<::pyo3::Bound<'py, ::pyo3::types::PyAny>>,
        p_bonus: ::std::option::Option<::pyo3::Bound<'py, ::pyo3::types::PyAny>>,
    }
    impl<'py> tallyCall<'py> {
        ///Supply Python argument "scores". Replaces a previous supplied value. Conversion can execute Python now; leaving this setter unused omits the argument.
        pub fn with_scores(
            mut self,
            p_scores: &::pyo3::Bound<'py, ::pyo3::types::PyTuple>,
        ) -> ::pyo3::PyResult<Self> {
            let py = self.__pyo3_py;
            self.p_scores = ::std::option::Option::Some(
                ::pyo3::IntoPyObjectExt::into_bound_py_any(p_scores, py)?,
            );
            ::std::result::Result::Ok(self)
        }
        ///Supply Python argument "bonus". Replaces a previous supplied value. Conversion can execute Python now; leaving this setter unused omits the argument.
        pub fn with_bonus(mut self, p_bonus: i64) -> ::pyo3::PyResult<Self> {
            let py = self.__pyo3_py;
            self.p_bonus = ::std::option::Option::Some(
                ::pyo3::IntoPyObjectExt::into_bound_py_any(p_bonus, py)?,
            );
            ::std::result::Result::Ok(self)
        }
        /// Invoke the current Python callable, using Python's current defaults.
        /// Nonempty variadic positional arguments require every preceding positional slot.
        pub fn call(self) -> ::pyo3::PyResult<i64> {
            let py = self.__pyo3_py;
            let __pyo3_kwargs = ::pyo3::types::PyDict::new(py);
            let __pyo3_variadic = self
                .p_scores
                .map(|value| value.cast_into::<::pyo3::types::PyTuple>())
                .transpose()?;
            let __pyo3_has_variadic = __pyo3_variadic
                .as_ref()
                .is_some_and(|value| ::pyo3::types::PyTupleMethods::len(value) != 0);
            let mut __pyo3_args = ::std::vec::Vec::<
                ::pyo3::Bound<'py, ::pyo3::types::PyAny>,
            >::new();
            let mut __pyo3_positional_gap = false;
            if let ::std::option::Option::Some(value) = self.p_bonus {
                ::pyo3::types::PyDictMethods::set_item(&__pyo3_kwargs, "bonus", value)?;
            }
            if let ::std::option::Option::Some(values) = __pyo3_variadic {
                __pyo3_args.extend(::pyo3::types::PyTupleMethods::iter(&values));
            }
            let __pyo3_args = ::pyo3::types::PyTuple::new(py, __pyo3_args)?;
            ::std::result::Result::Ok(
                ::pyo3::types::PyAnyMethods::extract(
                    &::pyo3::types::PyAnyMethods::call_method(
                        py.import(::pyo3::intern!(py, "greeting"))?.as_any(),
                        ::pyo3::intern!(py, "tally"),
                        __pyo3_args,
                        ::std::option::Option::Some(&__pyo3_kwargs),
                    )?,
                )?,
            )
        }
    }
    pub fn tally_builder<'py>(
        py: ::pyo3::Python<'py>,
    ) -> ::pyo3::PyResult<tallyCall<'py>> {
        ::std::result::Result::Ok(tallyCall {
            __pyo3_py: py,
            p_scores: ::std::option::Option::None,
            p_bonus: ::std::option::Option::None,
        })
    }
}
