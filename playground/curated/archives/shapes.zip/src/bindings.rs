#[allow(
    clippy::all,
    clippy::nursery,
    clippy::pedantic,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused
)]
/// Shapes that share behaviour through inheritance.
pub mod shapes {
    #[doc(hidden)]
    pub const PYO3_BINDGEN_GENERATOR_VERSION: &str = "0.6.0";
    #[doc(hidden)]
    pub const PYO3_BINDGEN_MODULE_NAME: &str = "shapes";
    #[doc(hidden)]
    pub const PYO3_BINDGEN_INPUT_HASH: &str = "fnv1a64:d77d7dfcfd3ce283";
    /// A circle given by its radius.
    #[derive(Debug)]
    pub struct Circle {
        obj: ::pyo3::Py<::pyo3::types::PyAny>,
    }
    #[automatically_derived]
    impl Circle {
        pub fn from_py_any<'py>(
            obj: ::pyo3::Bound<'py, ::pyo3::types::PyAny>,
        ) -> ::pyo3::PyResult<Self> {
            let py = obj.py();
            let expected_type = ::pyo3::types::PyAnyMethods::getattr(
                py.import(::pyo3::intern!(py, "shapes"))?.as_any(),
                ::pyo3::intern!(py, "Circle"),
            )?;
            if !::pyo3::types::PyAnyMethods::is_instance(
                obj.as_any(),
                expected_type.as_any(),
            )? {
                return ::std::result::Result::Err(
                    ::pyo3::exceptions::PyTypeError::new_err(
                        ::std::format!(
                            "expected Python instance of '{}'", "shapes.Circle"
                        ),
                    ),
                );
            }
            ::std::result::Result::Ok(Self { obj: obj.unbind() })
        }
        #[inline]
        pub fn bind<'py>(
            &self,
            py: ::pyo3::marker::Python<'py>,
        ) -> &::pyo3::Bound<'py, ::pyo3::types::PyAny> {
            self.obj.bind(py)
        }
        #[inline]
        pub fn as_any<'py>(
            &self,
            py: ::pyo3::marker::Python<'py>,
        ) -> &::pyo3::Bound<'py, ::pyo3::types::PyAny> {
            self.bind(py)
        }
        #[inline]
        pub fn clone_ref(&self, py: ::pyo3::marker::Python<'_>) -> Self {
            Self {
                obj: self.obj.clone_ref(py),
            }
        }
        #[inline]
        pub fn into_py_any(self) -> ::pyo3::Py<::pyo3::types::PyAny> {
            self.obj
        }
    }
    #[automatically_derived]
    impl<'py> ::pyo3::FromPyObject<'_, 'py> for Circle {
        type Error = ::pyo3::PyErr;
        fn extract(
            obj: ::pyo3::Borrowed<'_, 'py, ::pyo3::types::PyAny>,
        ) -> ::std::result::Result<Self, Self::Error> {
            Self::from_py_any(obj.to_owned())
        }
    }
    #[automatically_derived]
    impl<'py> ::pyo3::IntoPyObject<'py> for Circle {
        type Target = ::pyo3::types::PyAny;
        type Output = ::pyo3::Bound<'py, Self::Target>;
        type Error = ::std::convert::Infallible;
        fn into_pyobject(
            self,
            py: ::pyo3::marker::Python<'py>,
        ) -> ::std::result::Result<Self::Output, Self::Error> {
            ::std::result::Result::Ok(self.obj.into_bound(py))
        }
    }
    #[automatically_derived]
    impl<'a, 'py> ::pyo3::IntoPyObject<'py> for &'a Circle {
        type Target = ::pyo3::types::PyAny;
        type Output = ::pyo3::Borrowed<'a, 'py, Self::Target>;
        type Error = ::std::convert::Infallible;
        fn into_pyobject(
            self,
            py: ::pyo3::marker::Python<'py>,
        ) -> ::std::result::Result<Self::Output, Self::Error> {
            ::std::result::Result::Ok(self.obj.bind_borrowed(py))
        }
    }
    #[automatically_derived]
    impl Circle {
        pub fn new<'py>(
            py: ::pyo3::marker::Python<'py>,
            p_radius: f64,
        ) -> ::pyo3::PyResult<Self> {
            ::std::result::Result::Ok(
                ::pyo3::types::PyAnyMethods::extract(
                    &::pyo3::types::PyAnyMethods::call1(
                        ::pyo3::types::PyAnyMethods::getattr(
                                py.import(::pyo3::intern!(py, "shapes"))?.as_any(),
                                ::pyo3::intern!(py, "Circle"),
                            )?
                            .as_any(),
                        ::pyo3::types::PyTuple::new(
                            py,
                            [::pyo3::IntoPyObjectExt::into_bound_py_any(p_radius, py)?],
                        )?,
                    )?,
                )?,
            )
        }
    }
    /// These methods are defined on the owning Python object wrapper.
    #[doc(alias = "Circle")]
    #[automatically_derived]
    pub trait CircleMethods {
        fn area<'py>(&self, py: ::pyo3::marker::Python<'py>) -> ::pyo3::PyResult<f64>;
        fn describe<'py>(
            &self,
            py: ::pyo3::marker::Python<'py>,
        ) -> ::pyo3::PyResult<::std::string::String>;
    }
    #[automatically_derived]
    impl CircleMethods for Circle {
        fn area<'py>(&self, py: ::pyo3::marker::Python<'py>) -> ::pyo3::PyResult<f64> {
            ::std::result::Result::Ok(
                ::pyo3::types::PyAnyMethods::extract(
                    &::pyo3::types::PyAnyMethods::call_method0(
                        self.bind(py),
                        ::pyo3::intern!(py, "area"),
                    )?,
                )?,
            )
        }
        /// A short description of the shape.
        fn describe<'py>(
            &self,
            py: ::pyo3::marker::Python<'py>,
        ) -> ::pyo3::PyResult<::std::string::String> {
            ::std::result::Result::Ok(
                ::pyo3::types::PyAnyMethods::extract(
                    &::pyo3::types::PyAnyMethods::call_method0(
                        self.bind(py),
                        ::pyo3::intern!(py, "describe"),
                    )?,
                )?,
            )
        }
    }
    /// A plane figure.
    #[derive(Debug)]
    pub struct Shape {
        obj: ::pyo3::Py<::pyo3::types::PyAny>,
    }
    #[automatically_derived]
    impl Shape {
        pub fn from_py_any<'py>(
            obj: ::pyo3::Bound<'py, ::pyo3::types::PyAny>,
        ) -> ::pyo3::PyResult<Self> {
            let py = obj.py();
            let expected_type = ::pyo3::types::PyAnyMethods::getattr(
                py.import(::pyo3::intern!(py, "shapes"))?.as_any(),
                ::pyo3::intern!(py, "Shape"),
            )?;
            if !::pyo3::types::PyAnyMethods::is_instance(
                obj.as_any(),
                expected_type.as_any(),
            )? {
                return ::std::result::Result::Err(
                    ::pyo3::exceptions::PyTypeError::new_err(
                        ::std::format!(
                            "expected Python instance of '{}'", "shapes.Shape"
                        ),
                    ),
                );
            }
            ::std::result::Result::Ok(Self { obj: obj.unbind() })
        }
        #[inline]
        pub fn bind<'py>(
            &self,
            py: ::pyo3::marker::Python<'py>,
        ) -> &::pyo3::Bound<'py, ::pyo3::types::PyAny> {
            self.obj.bind(py)
        }
        #[inline]
        pub fn as_any<'py>(
            &self,
            py: ::pyo3::marker::Python<'py>,
        ) -> &::pyo3::Bound<'py, ::pyo3::types::PyAny> {
            self.bind(py)
        }
        #[inline]
        pub fn clone_ref(&self, py: ::pyo3::marker::Python<'_>) -> Self {
            Self {
                obj: self.obj.clone_ref(py),
            }
        }
        #[inline]
        pub fn into_py_any(self) -> ::pyo3::Py<::pyo3::types::PyAny> {
            self.obj
        }
    }
    #[automatically_derived]
    impl<'py> ::pyo3::FromPyObject<'_, 'py> for Shape {
        type Error = ::pyo3::PyErr;
        fn extract(
            obj: ::pyo3::Borrowed<'_, 'py, ::pyo3::types::PyAny>,
        ) -> ::std::result::Result<Self, Self::Error> {
            Self::from_py_any(obj.to_owned())
        }
    }
    #[automatically_derived]
    impl<'py> ::pyo3::IntoPyObject<'py> for Shape {
        type Target = ::pyo3::types::PyAny;
        type Output = ::pyo3::Bound<'py, Self::Target>;
        type Error = ::std::convert::Infallible;
        fn into_pyobject(
            self,
            py: ::pyo3::marker::Python<'py>,
        ) -> ::std::result::Result<Self::Output, Self::Error> {
            ::std::result::Result::Ok(self.obj.into_bound(py))
        }
    }
    #[automatically_derived]
    impl<'a, 'py> ::pyo3::IntoPyObject<'py> for &'a Shape {
        type Target = ::pyo3::types::PyAny;
        type Output = ::pyo3::Borrowed<'a, 'py, Self::Target>;
        type Error = ::std::convert::Infallible;
        fn into_pyobject(
            self,
            py: ::pyo3::marker::Python<'py>,
        ) -> ::std::result::Result<Self::Output, Self::Error> {
            ::std::result::Result::Ok(self.obj.bind_borrowed(py))
        }
    }
    #[automatically_derived]
    impl Shape {
        /// Initialize self. See help(type(self)) for accurate signature.
        pub fn new<'py>(
            py: ::pyo3::marker::Python<'py>,
            p_args: &::pyo3::Bound<'py, ::pyo3::types::PyTuple>,
            p_kwargs: ::std::option::Option<::pyo3::Bound<'py, ::pyo3::types::PyDict>>,
        ) -> ::pyo3::PyResult<Self> {
            let p_kwargs = if let Some(p_kwargs) = p_kwargs {
                ::pyo3::types::IntoPyDict::into_py_dict(p_kwargs, py)?
            } else {
                ::pyo3::types::PyDict::new(py)
            };
            ::std::result::Result::Ok(
                ::pyo3::types::PyAnyMethods::extract(
                    &::pyo3::types::PyAnyMethods::call(
                        ::pyo3::types::PyAnyMethods::getattr(
                                py.import(::pyo3::intern!(py, "shapes"))?.as_any(),
                                ::pyo3::intern!(py, "Shape"),
                            )?
                            .as_any(),
                        p_args,
                        Some(&p_kwargs),
                    )?,
                )?,
            )
        }
    }
    /// These methods are defined on the owning Python object wrapper.
    #[doc(alias = "Shape")]
    #[automatically_derived]
    pub trait ShapeMethods {
        fn area<'py>(&self, py: ::pyo3::marker::Python<'py>) -> ::pyo3::PyResult<f64>;
        fn describe<'py>(
            &self,
            py: ::pyo3::marker::Python<'py>,
        ) -> ::pyo3::PyResult<::std::string::String>;
    }
    #[automatically_derived]
    impl ShapeMethods for Shape {
        /// Area in square units.
        fn area<'py>(&self, py: ::pyo3::marker::Python<'py>) -> ::pyo3::PyResult<f64> {
            ::std::result::Result::Ok(
                ::pyo3::types::PyAnyMethods::extract(
                    &::pyo3::types::PyAnyMethods::call_method0(
                        self.bind(py),
                        ::pyo3::intern!(py, "area"),
                    )?,
                )?,
            )
        }
        /// A short description of the shape.
        fn describe<'py>(
            &self,
            py: ::pyo3::marker::Python<'py>,
        ) -> ::pyo3::PyResult<::std::string::String> {
            ::std::result::Result::Ok(
                ::pyo3::types::PyAnyMethods::extract(
                    &::pyo3::types::PyAnyMethods::call_method0(
                        self.bind(py),
                        ::pyo3::intern!(py, "describe"),
                    )?,
                )?,
            )
        }
    }
    /// A square given by its side.
    #[derive(Debug)]
    pub struct Square {
        obj: ::pyo3::Py<::pyo3::types::PyAny>,
    }
    #[automatically_derived]
    impl Square {
        pub fn from_py_any<'py>(
            obj: ::pyo3::Bound<'py, ::pyo3::types::PyAny>,
        ) -> ::pyo3::PyResult<Self> {
            let py = obj.py();
            let expected_type = ::pyo3::types::PyAnyMethods::getattr(
                py.import(::pyo3::intern!(py, "shapes"))?.as_any(),
                ::pyo3::intern!(py, "Square"),
            )?;
            if !::pyo3::types::PyAnyMethods::is_instance(
                obj.as_any(),
                expected_type.as_any(),
            )? {
                return ::std::result::Result::Err(
                    ::pyo3::exceptions::PyTypeError::new_err(
                        ::std::format!(
                            "expected Python instance of '{}'", "shapes.Square"
                        ),
                    ),
                );
            }
            ::std::result::Result::Ok(Self { obj: obj.unbind() })
        }
        #[inline]
        pub fn bind<'py>(
            &self,
            py: ::pyo3::marker::Python<'py>,
        ) -> &::pyo3::Bound<'py, ::pyo3::types::PyAny> {
            self.obj.bind(py)
        }
        #[inline]
        pub fn as_any<'py>(
            &self,
            py: ::pyo3::marker::Python<'py>,
        ) -> &::pyo3::Bound<'py, ::pyo3::types::PyAny> {
            self.bind(py)
        }
        #[inline]
        pub fn clone_ref(&self, py: ::pyo3::marker::Python<'_>) -> Self {
            Self {
                obj: self.obj.clone_ref(py),
            }
        }
        #[inline]
        pub fn into_py_any(self) -> ::pyo3::Py<::pyo3::types::PyAny> {
            self.obj
        }
    }
    #[automatically_derived]
    impl<'py> ::pyo3::FromPyObject<'_, 'py> for Square {
        type Error = ::pyo3::PyErr;
        fn extract(
            obj: ::pyo3::Borrowed<'_, 'py, ::pyo3::types::PyAny>,
        ) -> ::std::result::Result<Self, Self::Error> {
            Self::from_py_any(obj.to_owned())
        }
    }
    #[automatically_derived]
    impl<'py> ::pyo3::IntoPyObject<'py> for Square {
        type Target = ::pyo3::types::PyAny;
        type Output = ::pyo3::Bound<'py, Self::Target>;
        type Error = ::std::convert::Infallible;
        fn into_pyobject(
            self,
            py: ::pyo3::marker::Python<'py>,
        ) -> ::std::result::Result<Self::Output, Self::Error> {
            ::std::result::Result::Ok(self.obj.into_bound(py))
        }
    }
    #[automatically_derived]
    impl<'a, 'py> ::pyo3::IntoPyObject<'py> for &'a Square {
        type Target = ::pyo3::types::PyAny;
        type Output = ::pyo3::Borrowed<'a, 'py, Self::Target>;
        type Error = ::std::convert::Infallible;
        fn into_pyobject(
            self,
            py: ::pyo3::marker::Python<'py>,
        ) -> ::std::result::Result<Self::Output, Self::Error> {
            ::std::result::Result::Ok(self.obj.bind_borrowed(py))
        }
    }
    #[automatically_derived]
    impl Square {
        pub fn new<'py>(
            py: ::pyo3::marker::Python<'py>,
            p_side: f64,
        ) -> ::pyo3::PyResult<Self> {
            ::std::result::Result::Ok(
                ::pyo3::types::PyAnyMethods::extract(
                    &::pyo3::types::PyAnyMethods::call1(
                        ::pyo3::types::PyAnyMethods::getattr(
                                py.import(::pyo3::intern!(py, "shapes"))?.as_any(),
                                ::pyo3::intern!(py, "Square"),
                            )?
                            .as_any(),
                        ::pyo3::types::PyTuple::new(
                            py,
                            [::pyo3::IntoPyObjectExt::into_bound_py_any(p_side, py)?],
                        )?,
                    )?,
                )?,
            )
        }
    }
    /// These methods are defined on the owning Python object wrapper.
    #[doc(alias = "Square")]
    #[automatically_derived]
    pub trait SquareMethods {
        fn area<'py>(&self, py: ::pyo3::marker::Python<'py>) -> ::pyo3::PyResult<f64>;
        fn describe<'py>(
            &self,
            py: ::pyo3::marker::Python<'py>,
        ) -> ::pyo3::PyResult<::std::string::String>;
    }
    #[automatically_derived]
    impl SquareMethods for Square {
        fn area<'py>(&self, py: ::pyo3::marker::Python<'py>) -> ::pyo3::PyResult<f64> {
            ::std::result::Result::Ok(
                ::pyo3::types::PyAnyMethods::extract(
                    &::pyo3::types::PyAnyMethods::call_method0(
                        self.bind(py),
                        ::pyo3::intern!(py, "area"),
                    )?,
                )?,
            )
        }
        /// A short description of the shape.
        fn describe<'py>(
            &self,
            py: ::pyo3::marker::Python<'py>,
        ) -> ::pyo3::PyResult<::std::string::String> {
            ::std::result::Result::Ok(
                ::pyo3::types::PyAnyMethods::extract(
                    &::pyo3::types::PyAnyMethods::call_method0(
                        self.bind(py),
                        ::pyo3::intern!(py, "describe"),
                    )?,
                )?,
            )
        }
    }
}
