#[allow(
    clippy::all,
    clippy::nursery,
    clippy::pedantic,
    clippy::restriction,
    missing_docs,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    rustdoc::all,
    unused
)]
///Synthetic universal base trait of every generated Python-object newtype.
///
///Exposes the wrapped Python handle so default-bodied accessor/method
///traits can reach it generically. Also provides generic checked
///downcasts to any concrete newtype. Emitted once per generation.
pub trait PyObjectBase {
    ///Borrow the wrapped Python object handle.
    fn __pyo3_obj(&self) -> &::pyo3::Py<::pyo3::types::PyAny>;
    ///Borrow the wrapped Python object, bound to `py`.
    #[inline]
    fn bind<'py>(
        &self,
        py: ::pyo3::marker::Python<'py>,
    ) -> &::pyo3::Bound<'py, ::pyo3::types::PyAny> {
        self.__pyo3_obj().bind(py)
    }
    ///Borrow the wrapped Python object as an untyped `PyAny`.
    #[inline]
    fn as_any<'py>(
        &self,
        py: ::pyo3::marker::Python<'py>,
    ) -> &::pyo3::Bound<'py, ::pyo3::types::PyAny> {
        self.bind(py)
    }
    ///Checked downcast to a concrete newtype `U` via `isinstance`.
    ///
    ///Returns `Ok(Some(U))` when the wrapped object is an instance of
    ///`U`'s Python class, `Ok(None)` otherwise.
    fn try_downcast<U: PyTypeMarker>(
        &self,
        py: ::pyo3::marker::Python<'_>,
    ) -> ::pyo3::PyResult<::std::option::Option<U>>
    where
        Self: ::core::marker::Sized,
    {
        let expected_type = __pyo3_bindgen_resolve_py_type(
            py,
            <U as PyTypeMarker>::PY_CLASS,
        )?;
        let obj = self.__pyo3_obj().bind(py);
        if ::pyo3::types::PyAnyMethods::is_instance(obj, expected_type.as_any())? {
            ::std::result::Result::Ok(
                ::std::option::Option::Some(
                    <U as PyTypeMarker>::__from_obj(self.__pyo3_obj().clone_ref(py)),
                ),
            )
        } else {
            ::std::result::Result::Ok(::std::option::Option::None)
        }
    }
    ///Checked downcast to a concrete newtype `U`, erroring on mismatch.
    ///
    ///Like [`try_downcast`](Self::try_downcast) but maps a type mismatch
    ///to a Python `TypeError`.
    fn downcast<U: PyTypeMarker>(
        &self,
        py: ::pyo3::marker::Python<'_>,
    ) -> ::pyo3::PyResult<U>
    where
        Self: ::core::marker::Sized,
    {
        match self.try_downcast::<U>(py)? {
            ::std::option::Option::Some(value) => ::std::result::Result::Ok(value),
            ::std::option::Option::None => {
                ::std::result::Result::Err(
                    ::pyo3::exceptions::PyTypeError::new_err(
                        "checked downcast failed: object is not an instance of the target Python class",
                    ),
                )
            }
        }
    }
}
#[allow(
    clippy::all,
    clippy::nursery,
    clippy::pedantic,
    clippy::restriction,
    missing_docs,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    rustdoc::all,
    unused
)]
///Generic type marker for every generated Python-object newtype.
///
///Records the registered Python class name and the unchecked
///wrap/unwrap of the underlying handle, powering the zero-cost upcast
///impls and the checked downcasts. Emitted once per generation.
pub trait PyTypeMarker: ::core::marker::Sized + PyObjectBase {
    ///Fully-qualified, dotted Python class name of this newtype.
    const PY_CLASS: &'static ::core::primitive::str;
    ///Wrap a Python handle as this newtype without any type check.
    fn __from_obj(obj: ::pyo3::Py<::pyo3::types::PyAny>) -> Self;
    ///Unwrap this newtype back into its underlying Python handle.
    fn __into_obj(self) -> ::pyo3::Py<::pyo3::types::PyAny>;
    ///Clone this newtype, sharing the underlying Python object.
    #[inline]
    fn clone_ref(&self, py: ::pyo3::marker::Python<'_>) -> Self {
        Self::__from_obj(self.__pyo3_obj().clone_ref(py))
    }
}
#[allow(
    clippy::all,
    clippy::nursery,
    clippy::pedantic,
    clippy::restriction,
    missing_docs,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    rustdoc::all,
    unused
)]
///Resolve a dotted Python class path to its runtime type object.
///
///Imports the module prefix (everything before the final `.`) and
///`getattr`s the final segment. Generic helper emitted once per
///generation; powers the checked downcasts on [`PyObjectBase`].
pub fn __pyo3_bindgen_resolve_py_type<'py>(
    py: ::pyo3::marker::Python<'py>,
    py_class: &::core::primitive::str,
) -> ::pyo3::PyResult<::pyo3::Bound<'py, ::pyo3::types::PyAny>> {
    match py_class.rsplit_once('.') {
        ::std::option::Option::Some((module_path, attr)) => {
            let module = py.import(module_path)?;
            ::std::result::Result::Ok(
                ::pyo3::types::PyAnyMethods::getattr(module.as_any(), attr)?,
            )
        }
        ::std::option::Option::None => {
            ::std::result::Result::Ok(py.import(py_class)?.into_any())
        }
    }
}
#[allow(
    clippy::all,
    clippy::nursery,
    clippy::pedantic,
    clippy::restriction,
    missing_docs,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    rustdoc::all,
    unused
)]
/// Shapes that share behaviour through inheritance.
pub mod shapes {
    #[doc(hidden)]
    pub const PYO3_BINDGEN_GENERATOR_VERSION: &str = "0.6.0";
    #[doc(hidden)]
    pub const PYO3_BINDGEN_MODULE_NAME: &str = "shapes";
    #[doc(hidden)]
    pub const PYO3_BINDGEN_INPUT_HASH: &str = "fnv1a64:d77d7dfcfd3ce283";
    /// A circle given by its radius.
    #[derive(Debug)]
    #[repr(transparent)]
    pub struct Circle {
        obj: ::pyo3::Py<::pyo3::types::PyAny>,
    }
    impl Circle {
        pub fn from_py_any(
            obj: ::pyo3::Bound<'_, ::pyo3::types::PyAny>,
        ) -> ::pyo3::PyResult<Self> {
            let py = obj.py();
            let expected_type = ::pyo3::types::PyAnyMethods::getattr(
                py.import(::pyo3::intern!(py, "shapes"))?.as_any(),
                ::pyo3::intern!(py, "Circle"),
            )?;
            if !::pyo3::types::PyAnyMethods::is_instance(
                obj.as_any(),
                expected_type.as_any(),
            )? {
                return ::std::result::Result::Err(
                    ::pyo3::exceptions::PyTypeError::new_err(
                        ::std::format!(
                            "expected Python instance of '{}'", "shapes.Circle"
                        ),
                    ),
                );
            }
            ::std::result::Result::Ok(Self { obj: obj.unbind() })
        }
        #[inline]
        pub fn into_py_any(self) -> ::pyo3::Py<::pyo3::types::PyAny> {
            self.obj
        }
    }
    #[automatically_derived]
    impl<'py> ::pyo3::FromPyObject<'_, 'py> for Circle {
        type Error = ::pyo3::PyErr;
        fn extract(
            obj: ::pyo3::Borrowed<'_, 'py, ::pyo3::types::PyAny>,
        ) -> ::std::result::Result<Self, Self::Error> {
            Self::from_py_any(obj.to_owned())
        }
    }
    #[automatically_derived]
    impl<'py> ::pyo3::IntoPyObject<'py> for Circle {
        type Target = ::pyo3::types::PyAny;
        type Output = ::pyo3::Bound<'py, Self::Target>;
        type Error = ::std::convert::Infallible;
        fn into_pyobject(
            self,
            py: ::pyo3::marker::Python<'py>,
        ) -> ::std::result::Result<Self::Output, Self::Error> {
            ::std::result::Result::Ok(self.obj.into_bound(py))
        }
    }
    #[automatically_derived]
    impl<'a, 'py> ::pyo3::IntoPyObject<'py> for &'a Circle {
        type Target = ::pyo3::types::PyAny;
        type Output = ::pyo3::Borrowed<'a, 'py, Self::Target>;
        type Error = ::std::convert::Infallible;
        fn into_pyobject(
            self,
            py: ::pyo3::marker::Python<'py>,
        ) -> ::std::result::Result<Self::Output, Self::Error> {
            ::std::result::Result::Ok(self.obj.bind_borrowed(py))
        }
    }
    impl Circle {
        pub fn new(
            py: ::pyo3::marker::Python<'_>,
            p_radius: ::core::primitive::f64,
        ) -> ::pyo3::PyResult<Self> {
            ::std::result::Result::Ok(
                ::pyo3::types::PyAnyMethods::extract(
                    &::pyo3::types::PyAnyMethods::call1(
                        ::pyo3::types::PyAnyMethods::getattr(
                                py.import(::pyo3::intern!(py, "shapes"))?.as_any(),
                                ::pyo3::intern!(py, "Circle"),
                            )?
                            .as_any(),
                        ::pyo3::types::PyTuple::new(
                            py,
                            [::pyo3::IntoPyObjectExt::into_bound_py_any(p_radius, py)?],
                        )?,
                    )?,
                )?,
            )
        }
    }
    /// These methods are defined on the owning Python object wrapper.
    #[doc(alias = "Circle")]
    pub trait CircleMethods: ShapeMethods {
        fn area(
            &self,
            py: ::pyo3::marker::Python<'_>,
        ) -> ::pyo3::PyResult<::core::primitive::f64> {
            ::std::result::Result::Ok(
                ::pyo3::types::PyAnyMethods::extract(
                    &::pyo3::types::PyAnyMethods::call_method0(
                        self.__pyo3_obj().bind(py),
                        ::pyo3::intern!(py, "area"),
                    )?,
                )?,
            )
        }
    }
    #[automatically_derived]
    impl super::PyObjectBase for Circle {
        #[inline]
        fn __pyo3_obj(&self) -> &::pyo3::Py<::pyo3::types::PyAny> {
            &self.obj
        }
    }
    #[automatically_derived]
    impl CircleMethods for Circle {}
    #[automatically_derived]
    impl ShapeMethods for Circle {}
    impl Circle {
        #[inline]
        pub fn area(
            &self,
            py: ::pyo3::marker::Python<'_>,
        ) -> ::pyo3::PyResult<::core::primitive::f64> {
            <Self as CircleMethods>::area(self, py)
        }
    }
    #[automatically_derived]
    impl super::PyTypeMarker for Circle {
        const PY_CLASS: &'static ::core::primitive::str = "shapes.Circle";
        #[inline]
        fn __from_obj(obj: ::pyo3::Py<::pyo3::types::PyAny>) -> Self {
            Self { obj }
        }
        #[inline]
        fn __into_obj(self) -> ::pyo3::Py<::pyo3::types::PyAny> {
            self.obj
        }
    }
    #[automatically_derived]
    impl ::core::convert::AsRef<Shape> for Circle {
        #[inline]
        fn as_ref(&self) -> &Shape {
            unsafe { &*(self as *const Self as *const Shape) }
        }
    }
    #[automatically_derived]
    impl ::core::convert::From<Circle> for Shape {
        #[inline]
        fn from(value: Circle) -> Self {
            <Shape as super::PyTypeMarker>::__from_obj(
                <Circle as super::PyTypeMarker>::__into_obj(value),
            )
        }
    }
    /// A plane figure.
    #[derive(Debug)]
    #[repr(transparent)]
    pub struct Shape {
        obj: ::pyo3::Py<::pyo3::types::PyAny>,
    }
    impl Shape {
        pub fn from_py_any(
            obj: ::pyo3::Bound<'_, ::pyo3::types::PyAny>,
        ) -> ::pyo3::PyResult<Self> {
            let py = obj.py();
            let expected_type = ::pyo3::types::PyAnyMethods::getattr(
                py.import(::pyo3::intern!(py, "shapes"))?.as_any(),
                ::pyo3::intern!(py, "Shape"),
            )?;
            if !::pyo3::types::PyAnyMethods::is_instance(
                obj.as_any(),
                expected_type.as_any(),
            )? {
                return ::std::result::Result::Err(
                    ::pyo3::exceptions::PyTypeError::new_err(
                        ::std::format!(
                            "expected Python instance of '{}'", "shapes.Shape"
                        ),
                    ),
                );
            }
            ::std::result::Result::Ok(Self { obj: obj.unbind() })
        }
        #[inline]
        pub fn into_py_any(self) -> ::pyo3::Py<::pyo3::types::PyAny> {
            self.obj
        }
    }
    #[automatically_derived]
    impl<'py> ::pyo3::FromPyObject<'_, 'py> for Shape {
        type Error = ::pyo3::PyErr;
        fn extract(
            obj: ::pyo3::Borrowed<'_, 'py, ::pyo3::types::PyAny>,
        ) -> ::std::result::Result<Self, Self::Error> {
            Self::from_py_any(obj.to_owned())
        }
    }
    #[automatically_derived]
    impl<'py> ::pyo3::IntoPyObject<'py> for Shape {
        type Target = ::pyo3::types::PyAny;
        type Output = ::pyo3::Bound<'py, Self::Target>;
        type Error = ::std::convert::Infallible;
        fn into_pyobject(
            self,
            py: ::pyo3::marker::Python<'py>,
        ) -> ::std::result::Result<Self::Output, Self::Error> {
            ::std::result::Result::Ok(self.obj.into_bound(py))
        }
    }
    #[automatically_derived]
    impl<'a, 'py> ::pyo3::IntoPyObject<'py> for &'a Shape {
        type Target = ::pyo3::types::PyAny;
        type Output = ::pyo3::Borrowed<'a, 'py, Self::Target>;
        type Error = ::std::convert::Infallible;
        fn into_pyobject(
            self,
            py: ::pyo3::marker::Python<'py>,
        ) -> ::std::result::Result<Self::Output, Self::Error> {
            ::std::result::Result::Ok(self.obj.bind_borrowed(py))
        }
    }
    impl Shape {
        /// Initialize self. See help(type(self)) for accurate signature.
        pub fn new<'py>(
            py: ::pyo3::marker::Python<'py>,
            p_args: &::pyo3::Bound<'py, ::pyo3::types::PyTuple>,
            p_kwargs: ::std::option::Option<::pyo3::Bound<'py, ::pyo3::types::PyDict>>,
        ) -> ::pyo3::PyResult<Self> {
            let p_kwargs = if let ::core::option::Option::Some(p_kwargs) = p_kwargs {
                ::pyo3::types::IntoPyDict::into_py_dict(p_kwargs, py)?
            } else {
                ::pyo3::types::PyDict::new(py)
            };
            ::std::result::Result::Ok(
                ::pyo3::types::PyAnyMethods::extract(
                    &::pyo3::types::PyAnyMethods::call(
                        ::pyo3::types::PyAnyMethods::getattr(
                                py.import(::pyo3::intern!(py, "shapes"))?.as_any(),
                                ::pyo3::intern!(py, "Shape"),
                            )?
                            .as_any(),
                        p_args,
                        ::core::option::Option::Some(&p_kwargs),
                    )?,
                )?,
            )
        }
    }
    /// These methods are defined on the owning Python object wrapper.
    #[doc(alias = "Shape")]
    pub trait ShapeMethods: super::PyObjectBase {
        /// Area in square units.
        fn area(
            &self,
            py: ::pyo3::marker::Python<'_>,
        ) -> ::pyo3::PyResult<::core::primitive::f64> {
            ::std::result::Result::Ok(
                ::pyo3::types::PyAnyMethods::extract(
                    &::pyo3::types::PyAnyMethods::call_method0(
                        self.__pyo3_obj().bind(py),
                        ::pyo3::intern!(py, "area"),
                    )?,
                )?,
            )
        }
        /// A short description of the shape.
        fn describe(
            &self,
            py: ::pyo3::marker::Python<'_>,
        ) -> ::pyo3::PyResult<::std::string::String> {
            ::std::result::Result::Ok(
                ::pyo3::types::PyAnyMethods::extract(
                    &::pyo3::types::PyAnyMethods::call_method0(
                        self.__pyo3_obj().bind(py),
                        ::pyo3::intern!(py, "describe"),
                    )?,
                )?,
            )
        }
    }
    #[automatically_derived]
    impl super::PyObjectBase for Shape {
        #[inline]
        fn __pyo3_obj(&self) -> &::pyo3::Py<::pyo3::types::PyAny> {
            &self.obj
        }
    }
    #[automatically_derived]
    impl ShapeMethods for Shape {}
    impl Shape {
        #[inline]
        pub fn area(
            &self,
            py: ::pyo3::marker::Python<'_>,
        ) -> ::pyo3::PyResult<::core::primitive::f64> {
            <Self as ShapeMethods>::area(self, py)
        }
        #[inline]
        pub fn describe(
            &self,
            py: ::pyo3::marker::Python<'_>,
        ) -> ::pyo3::PyResult<::std::string::String> {
            <Self as ShapeMethods>::describe(self, py)
        }
    }
    #[automatically_derived]
    impl super::PyTypeMarker for Shape {
        const PY_CLASS: &'static ::core::primitive::str = "shapes.Shape";
        #[inline]
        fn __from_obj(obj: ::pyo3::Py<::pyo3::types::PyAny>) -> Self {
            Self { obj }
        }
        #[inline]
        fn __into_obj(self) -> ::pyo3::Py<::pyo3::types::PyAny> {
            self.obj
        }
    }
    /// A square given by its side.
    #[derive(Debug)]
    #[repr(transparent)]
    pub struct Square {
        obj: ::pyo3::Py<::pyo3::types::PyAny>,
    }
    impl Square {
        pub fn from_py_any(
            obj: ::pyo3::Bound<'_, ::pyo3::types::PyAny>,
        ) -> ::pyo3::PyResult<Self> {
            let py = obj.py();
            let expected_type = ::pyo3::types::PyAnyMethods::getattr(
                py.import(::pyo3::intern!(py, "shapes"))?.as_any(),
                ::pyo3::intern!(py, "Square"),
            )?;
            if !::pyo3::types::PyAnyMethods::is_instance(
                obj.as_any(),
                expected_type.as_any(),
            )? {
                return ::std::result::Result::Err(
                    ::pyo3::exceptions::PyTypeError::new_err(
                        ::std::format!(
                            "expected Python instance of '{}'", "shapes.Square"
                        ),
                    ),
                );
            }
            ::std::result::Result::Ok(Self { obj: obj.unbind() })
        }
        #[inline]
        pub fn into_py_any(self) -> ::pyo3::Py<::pyo3::types::PyAny> {
            self.obj
        }
    }
    #[automatically_derived]
    impl<'py> ::pyo3::FromPyObject<'_, 'py> for Square {
        type Error = ::pyo3::PyErr;
        fn extract(
            obj: ::pyo3::Borrowed<'_, 'py, ::pyo3::types::PyAny>,
        ) -> ::std::result::Result<Self, Self::Error> {
            Self::from_py_any(obj.to_owned())
        }
    }
    #[automatically_derived]
    impl<'py> ::pyo3::IntoPyObject<'py> for Square {
        type Target = ::pyo3::types::PyAny;
        type Output = ::pyo3::Bound<'py, Self::Target>;
        type Error = ::std::convert::Infallible;
        fn into_pyobject(
            self,
            py: ::pyo3::marker::Python<'py>,
        ) -> ::std::result::Result<Self::Output, Self::Error> {
            ::std::result::Result::Ok(self.obj.into_bound(py))
        }
    }
    #[automatically_derived]
    impl<'a, 'py> ::pyo3::IntoPyObject<'py> for &'a Square {
        type Target = ::pyo3::types::PyAny;
        type Output = ::pyo3::Borrowed<'a, 'py, Self::Target>;
        type Error = ::std::convert::Infallible;
        fn into_pyobject(
            self,
            py: ::pyo3::marker::Python<'py>,
        ) -> ::std::result::Result<Self::Output, Self::Error> {
            ::std::result::Result::Ok(self.obj.bind_borrowed(py))
        }
    }
    impl Square {
        pub fn new(
            py: ::pyo3::marker::Python<'_>,
            p_side: ::core::primitive::f64,
        ) -> ::pyo3::PyResult<Self> {
            ::std::result::Result::Ok(
                ::pyo3::types::PyAnyMethods::extract(
                    &::pyo3::types::PyAnyMethods::call1(
                        ::pyo3::types::PyAnyMethods::getattr(
                                py.import(::pyo3::intern!(py, "shapes"))?.as_any(),
                                ::pyo3::intern!(py, "Square"),
                            )?
                            .as_any(),
                        ::pyo3::types::PyTuple::new(
                            py,
                            [::pyo3::IntoPyObjectExt::into_bound_py_any(p_side, py)?],
                        )?,
                    )?,
                )?,
            )
        }
    }
    /// These methods are defined on the owning Python object wrapper.
    #[doc(alias = "Square")]
    pub trait SquareMethods: ShapeMethods {
        fn area(
            &self,
            py: ::pyo3::marker::Python<'_>,
        ) -> ::pyo3::PyResult<::core::primitive::f64> {
            ::std::result::Result::Ok(
                ::pyo3::types::PyAnyMethods::extract(
                    &::pyo3::types::PyAnyMethods::call_method0(
                        self.__pyo3_obj().bind(py),
                        ::pyo3::intern!(py, "area"),
                    )?,
                )?,
            )
        }
    }
    #[automatically_derived]
    impl super::PyObjectBase for Square {
        #[inline]
        fn __pyo3_obj(&self) -> &::pyo3::Py<::pyo3::types::PyAny> {
            &self.obj
        }
    }
    #[automatically_derived]
    impl SquareMethods for Square {}
    #[automatically_derived]
    impl ShapeMethods for Square {}
    impl Square {
        #[inline]
        pub fn area(
            &self,
            py: ::pyo3::marker::Python<'_>,
        ) -> ::pyo3::PyResult<::core::primitive::f64> {
            <Self as SquareMethods>::area(self, py)
        }
    }
    #[automatically_derived]
    impl super::PyTypeMarker for Square {
        const PY_CLASS: &'static ::core::primitive::str = "shapes.Square";
        #[inline]
        fn __from_obj(obj: ::pyo3::Py<::pyo3::types::PyAny>) -> Self {
            Self { obj }
        }
        #[inline]
        fn __into_obj(self) -> ::pyo3::Py<::pyo3::types::PyAny> {
            self.obj
        }
    }
    #[automatically_derived]
    impl ::core::convert::AsRef<Shape> for Square {
        #[inline]
        fn as_ref(&self) -> &Shape {
            unsafe { &*(self as *const Self as *const Shape) }
        }
    }
    #[automatically_derived]
    impl ::core::convert::From<Square> for Shape {
        #[inline]
        fn from(value: Square) -> Self {
            <Shape as super::PyTypeMarker>::__from_obj(
                <Square as super::PyTypeMarker>::__into_obj(value),
            )
        }
    }
}
