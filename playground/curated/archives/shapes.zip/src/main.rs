use pyo3::{prelude::*, types::PyModule};
use std::ffi::CString;

include!("bindings.rs");

fn main() -> PyResult<()> {
    Python::attach(|py| {
        let source = CString::new(include_str!("../shapes.py"))
            .expect("fixture source contains no NUL byte");
        let filename = CString::new("shapes.py").expect("static filename contains no NUL byte");
        let module_name = CString::new("shapes").expect("static module name contains no NUL byte");
        let module = PyModule::from_code(
            py,
            source.as_c_str(),
            filename.as_c_str(),
            module_name.as_c_str(),
        )?;
        py.import("sys")?.getattr("modules")?.set_item("shapes", module)?;
        use shapes::CircleMethods;
        let circle = shapes::Circle::new(py, 2.0)?;
        let description = circle.describe(py)?;
        assert_eq!(description, "Circle with area 12.57");
        println!("shapes: {description}");
        Ok(())
    })
}
