use pyo3::{prelude::*, types::PyModule};
use std::ffi::CString;

include!("bindings.rs");

fn main() -> PyResult<()> {
    Python::attach(|py| {
        let source = CString::new(include_str!("../palette.py"))
            .expect("fixture source contains no NUL byte");
        let filename = CString::new("palette.py").expect("static filename contains no NUL byte");
        let module_name = CString::new("palette").expect("static module name contains no NUL byte");
        let module = PyModule::from_code(
            py,
            source.as_c_str(),
            filename.as_c_str(),
            module_name.as_c_str(),
        )?;
        py.import("sys")?.getattr("modules")?.set_item("palette", module)?;
        let colour = palette::Colour::Red;
        let green = palette::Colour::Green;
        let mixed = palette::mix(py, &colour, &green)?;
        assert_eq!(mixed, "yellow");
        println!("palette: {mixed}");
        Ok(())
    })
}
