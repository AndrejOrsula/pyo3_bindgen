#[allow(
    clippy::all,
    clippy::nursery,
    clippy::pedantic,
    clippy::restriction,
    missing_docs,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    rustdoc::all,
    unused
)]
/// Colours as enums, which become Rust enums.
pub mod palette {
    #[doc(hidden)]
    pub const PYO3_BINDGEN_GENERATOR_VERSION: &str = "0.6.0";
    #[doc(hidden)]
    pub const PYO3_BINDGEN_MODULE_NAME: &str = "palette";
    #[doc(hidden)]
    pub const PYO3_BINDGEN_INPUT_HASH: &str = "fnv1a64:cd0b8d5a255f311f";
    /// Python enum mirror for `palette.Colour`.
    /// A primary colour.
    #[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
    pub enum Colour {
        /// Python enum member `palette.Colour.RED` with value `1`.
        #[doc(alias = "RED")]
        Red,
        /// Python enum member `palette.Colour.GREEN` with value `2`.
        #[doc(alias = "GREEN")]
        Green,
        /// Python enum member `palette.Colour.BLUE` with value `3`.
        #[doc(alias = "BLUE")]
        Blue,
    }
    impl Colour {
        pub fn as_py_name(self) -> &'static ::core::primitive::str {
            match self {
                Self::Red => "RED",
                Self::Green => "GREEN",
                Self::Blue => "BLUE",
            }
        }
        pub fn from_py_name(name: &::core::primitive::str) -> ::pyo3::PyResult<Self> {
            match name {
                "RED" => ::std::result::Result::Ok(Self::Red),
                "GREEN" => ::std::result::Result::Ok(Self::Green),
                "BLUE" => ::std::result::Result::Ok(Self::Blue),
                _ => {
                    ::std::result::Result::Err(
                        ::pyo3::exceptions::PyValueError::new_err(
                            ::std::format!(
                                "unknown Python enum member '{}.{}'", "palette.Colour", name
                            ),
                        ),
                    )
                }
            }
        }
        pub fn into_py_any<'py>(
            self,
            py: ::pyo3::marker::Python<'py>,
        ) -> ::pyo3::PyResult<::pyo3::Bound<'py, ::pyo3::types::PyAny>> {
            let enum_type = ::pyo3::types::PyAnyMethods::getattr(
                py.import(::pyo3::intern!(py, "palette"))?.as_any(),
                ::pyo3::intern!(py, "Colour"),
            )?;
            ::pyo3::types::PyAnyMethods::getattr(enum_type.as_any(), self.as_py_name())
        }
    }
    #[automatically_derived]
    impl<'py> ::pyo3::FromPyObject<'_, 'py> for Colour {
        type Error = ::pyo3::PyErr;
        fn extract(
            obj: ::pyo3::Borrowed<'_, 'py, ::pyo3::types::PyAny>,
        ) -> ::std::result::Result<Self, ::pyo3::PyErr> {
            let py = obj.py();
            let expected_type = ::pyo3::types::PyAnyMethods::getattr(
                py.import(::pyo3::intern!(py, "palette"))?.as_any(),
                ::pyo3::intern!(py, "Colour"),
            )?;
            if !::pyo3::types::PyAnyMethods::is_instance(
                obj.as_any(),
                expected_type.as_any(),
            )? {
                return ::std::result::Result::Err(
                    ::pyo3::exceptions::PyTypeError::new_err(
                        ::std::format!(
                            "expected Python enum member of '{}'", "palette.Colour"
                        ),
                    ),
                );
            }
            let name_attr = ::pyo3::types::PyAnyMethods::getattr(
                obj.as_any(),
                ::pyo3::intern!(py, "name"),
            )?;
            let member_name = ::pyo3::types::PyAnyMethods::extract::<
                ::std::string::String,
            >(&name_attr)?;
            Self::from_py_name(&member_name)
        }
    }
    #[automatically_derived]
    impl<'py> ::pyo3::IntoPyObject<'py> for Colour {
        type Target = ::pyo3::types::PyAny;
        type Output = ::pyo3::Bound<'py, ::pyo3::types::PyAny>;
        type Error = ::pyo3::PyErr;
        fn into_pyobject(
            self,
            py: ::pyo3::marker::Python<'py>,
        ) -> ::std::result::Result<
            ::pyo3::Bound<'py, ::pyo3::types::PyAny>,
            ::pyo3::PyErr,
        > {
            self.into_py_any(py)
        }
    }
    #[automatically_derived]
    impl<'a, 'py> ::pyo3::IntoPyObject<'py> for &'a Colour {
        type Target = ::pyo3::types::PyAny;
        type Output = ::pyo3::Bound<'py, ::pyo3::types::PyAny>;
        type Error = ::pyo3::PyErr;
        fn into_pyobject(
            self,
            py: ::pyo3::marker::Python<'py>,
        ) -> ::std::result::Result<
            ::pyo3::Bound<'py, ::pyo3::types::PyAny>,
            ::pyo3::PyErr,
        > {
            (*self).into_py_any(py)
        }
    }
    /// Python enum mirror for `palette.Finish`.
    /// How a surface reflects light.
    #[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
    pub enum Finish {
        /// Python enum member `palette.Finish.MATTE` with value `'matte'`.
        #[doc(alias = "MATTE")]
        Matte,
        /// Python enum member `palette.Finish.GLOSS` with value `'gloss'`.
        #[doc(alias = "GLOSS")]
        Gloss,
    }
    impl Finish {
        pub fn as_py_name(self) -> &'static ::core::primitive::str {
            match self {
                Self::Matte => "MATTE",
                Self::Gloss => "GLOSS",
            }
        }
        pub fn from_py_name(name: &::core::primitive::str) -> ::pyo3::PyResult<Self> {
            match name {
                "MATTE" => ::std::result::Result::Ok(Self::Matte),
                "GLOSS" => ::std::result::Result::Ok(Self::Gloss),
                _ => {
                    ::std::result::Result::Err(
                        ::pyo3::exceptions::PyValueError::new_err(
                            ::std::format!(
                                "unknown Python enum member '{}.{}'", "palette.Finish", name
                            ),
                        ),
                    )
                }
            }
        }
        pub fn into_py_any<'py>(
            self,
            py: ::pyo3::marker::Python<'py>,
        ) -> ::pyo3::PyResult<::pyo3::Bound<'py, ::pyo3::types::PyAny>> {
            let enum_type = ::pyo3::types::PyAnyMethods::getattr(
                py.import(::pyo3::intern!(py, "palette"))?.as_any(),
                ::pyo3::intern!(py, "Finish"),
            )?;
            ::pyo3::types::PyAnyMethods::getattr(enum_type.as_any(), self.as_py_name())
        }
    }
    #[automatically_derived]
    impl<'py> ::pyo3::FromPyObject<'_, 'py> for Finish {
        type Error = ::pyo3::PyErr;
        fn extract(
            obj: ::pyo3::Borrowed<'_, 'py, ::pyo3::types::PyAny>,
        ) -> ::std::result::Result<Self, ::pyo3::PyErr> {
            let py = obj.py();
            let expected_type = ::pyo3::types::PyAnyMethods::getattr(
                py.import(::pyo3::intern!(py, "palette"))?.as_any(),
                ::pyo3::intern!(py, "Finish"),
            )?;
            if !::pyo3::types::PyAnyMethods::is_instance(
                obj.as_any(),
                expected_type.as_any(),
            )? {
                return ::std::result::Result::Err(
                    ::pyo3::exceptions::PyTypeError::new_err(
                        ::std::format!(
                            "expected Python enum member of '{}'", "palette.Finish"
                        ),
                    ),
                );
            }
            let name_attr = ::pyo3::types::PyAnyMethods::getattr(
                obj.as_any(),
                ::pyo3::intern!(py, "name"),
            )?;
            let member_name = ::pyo3::types::PyAnyMethods::extract::<
                ::std::string::String,
            >(&name_attr)?;
            Self::from_py_name(&member_name)
        }
    }
    #[automatically_derived]
    impl<'py> ::pyo3::IntoPyObject<'py> for Finish {
        type Target = ::pyo3::types::PyAny;
        type Output = ::pyo3::Bound<'py, ::pyo3::types::PyAny>;
        type Error = ::pyo3::PyErr;
        fn into_pyobject(
            self,
            py: ::pyo3::marker::Python<'py>,
        ) -> ::std::result::Result<
            ::pyo3::Bound<'py, ::pyo3::types::PyAny>,
            ::pyo3::PyErr,
        > {
            self.into_py_any(py)
        }
    }
    #[automatically_derived]
    impl<'a, 'py> ::pyo3::IntoPyObject<'py> for &'a Finish {
        type Target = ::pyo3::types::PyAny;
        type Output = ::pyo3::Bound<'py, ::pyo3::types::PyAny>;
        type Error = ::pyo3::PyErr;
        fn into_pyobject(
            self,
            py: ::pyo3::marker::Python<'py>,
        ) -> ::std::result::Result<
            ::pyo3::Bound<'py, ::pyo3::types::PyAny>,
            ::pyo3::PyErr,
        > {
            (*self).into_py_any(py)
        }
    }
    /// Names the colour that two primaries of light make together.
    pub fn mix(
        py: ::pyo3::marker::Python<'_>,
        p_first: &Colour,
        p_second: &Colour,
    ) -> ::pyo3::PyResult<::std::string::String> {
        ::std::result::Result::Ok(
            ::pyo3::types::PyAnyMethods::extract(
                &::pyo3::types::PyAnyMethods::call_method1(
                    py.import(::pyo3::intern!(py, "palette"))?.as_any(),
                    ::pyo3::intern!(py, "mix"),
                    ::pyo3::types::PyTuple::new(
                        py,
                        [
                            ::pyo3::IntoPyObjectExt::into_bound_py_any(p_first, py)?,
                            ::pyo3::IntoPyObjectExt::into_bound_py_any(p_second, py)?,
                        ],
                    )?,
                )?,
            )?,
        )
    }
    /// Describes a coat of paint.
    pub fn paint(
        py: ::pyo3::marker::Python<'_>,
        p_colour: &Colour,
        p_finish: &Finish,
    ) -> ::pyo3::PyResult<::std::string::String> {
        ::std::result::Result::Ok(
            ::pyo3::types::PyAnyMethods::extract(
                &::pyo3::types::PyAnyMethods::call_method1(
                    py.import(::pyo3::intern!(py, "palette"))?.as_any(),
                    ::pyo3::intern!(py, "paint"),
                    ::pyo3::types::PyTuple::new(
                        py,
                        [
                            ::pyo3::IntoPyObjectExt::into_bound_py_any(p_colour, py)?,
                            ::pyo3::IntoPyObjectExt::into_bound_py_any(p_finish, py)?,
                        ],
                    )?,
                )?,
            )?,
        )
    }
    pub fn MIXES<'py>(
        py: ::pyo3::marker::Python<'py>,
    ) -> ::pyo3::PyResult<::pyo3::Bound<'py, ::pyo3::types::PyDict>> {
        ::std::result::Result::Ok(
            ::pyo3::types::PyAnyMethods::extract(
                &::pyo3::types::PyAnyMethods::getattr(
                    py.import(::pyo3::intern!(py, "palette"))?.as_any(),
                    ::pyo3::intern!(py, "MIXES"),
                )?,
            )?,
        )
    }
    pub fn set_MIXES<'py>(
        py: ::pyo3::marker::Python<'py>,
        p_value: impl ::pyo3::IntoPyObject<'py, Target = ::pyo3::types::PyDict>,
    ) -> ::pyo3::PyResult<()> {
        ::pyo3::types::PyAnyMethods::setattr(
            py.import(::pyo3::intern!(py, "palette"))?.as_any(),
            ::pyo3::intern!(py, "MIXES"),
            p_value,
        )
    }
}
